/*
 * Lab 4 Serial Port Programming.c
 *
 * Created: 04-Nov-20 10:08:53 AM
 * Author : flow
 */ 

//this program models the lecture notes where it returns a capitalized version of the inputted character. a->A
#include <avr/io.h>
#define fosc 16000000	//clock speed
#define baud 4800		//baud rate 4800
#define ubrr fosc/16/baud-1	//ubrr

void transmit (unsigned char data);

int main(void)
{
    //enable receiver and transmitter
    UCSR0B = (1<<RXEN0)|(1<<TXEN0);
	//set frame format: 8data, 2 stop bit
	UCSR0C = (1<<USBS0)|(3<<UCSZ00);
	UBRR0L = ubrr;
	
	//send & receive
	unsigned char ch;
    while (1) 
    {
		while(!(UCSR0A&(1<<RXC0)));		//while new data received
			ch = UDR0;
//		if (ch >= 'a' && ch<='z')		//comment out this line if u don't want it capitalized
//		{								//comment out this line if u don't want it capitalized
//			ch+=('A'-'a');				//comment out this line if u don't want it capitalized
		while(!(UCSR0A&(1<<UDRE0)));
			UDR0 = ch;
	//	}								//comment out this line if u don't want it capitalized
    }
	return 0;
}

