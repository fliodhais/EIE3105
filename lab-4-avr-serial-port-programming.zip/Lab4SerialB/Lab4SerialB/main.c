/*
 * Lab4SerialB.c
 *
 * Created: 04-Nov-20 10:08:53 AM
 * Author : flow
 */ 

//at start send "we are ready"
#include <avr/io.h>
#define fosc 16000000	//clock speed
#define baud 4800		//baud rate 9600 (originally 4800, changed due to teraterm's default value) (changed back to 4800 cause why not)
#define ubrr fosc/16/baud-1	//ubrr
unsigned char data;

void usart_init(void)
{
	UCSR0B = (1<<RXEN0)|(1<<TXEN0);			//enable receiver and transmitter
	UCSR0C = (1<<USBS0)|(3<<UCSZ00);		//set frame format: 2 stop bit, 8 data bit
	UBRR0L = ubrr;
}

//send data
void usart_send(unsigned char ch)
{
	while(!(UCSR0A&(1<<UDRE0)));	//wait for empty transmit buffer
	UDR0 = ch;						//put data into buffer, send data
}

//receive data
unsigned char usart_receive(void)
{
	while(!(UCSR0A & (1<<RXC0)));
	data = UDR0;
	return data;
}
int main(void)
{
	unsigned char start[13] = "We are Ready!";
	unsigned char startL = 13;
	unsigned char end[5] = "Bye! ";		
	unsigned char endL = 5;
	unsigned int flag=0;
	unsigned int i=0;
	unsigned char rec;
	usart_init();
	
	//send start message
	for(i=0;i<startL;i++)
	{
		usart_send(start[i]);
	}
    while (1) 
    {
		rec=usart_receive();
		
		//detect "Hi!"
		if (rec==('H'))
		{
			flag=1;
		}
		if (rec==('i') && flag==1)
		{
			flag=2;
		}
		if (rec==('!') && flag==2)
		{
			flag=3;
		}
		if(flag==3)
		{
			//send "Bye!"
			for(i=0;i<=endL;i++)
			{
				usart_send(end[i]);
			}
			flag=0;
		}
	}
	return 0;
}





/*	//working bit that spams continuously
void usart_init(void)
{
	UCSR0B = (1<<TXEN0);					//enable transmit
	UCSR0C = (1<<USBS0)|(3<<UCSZ00);	//8 data, 2 stop bits
	UBRR0L = ubrr;
}
void usart_send (unsigned char ch)
{
	while (! (UCSR0A & (1<<UDRE0)));
	UDR0=ch;
}
int main(void)
{
	unsigned char str[30]="The earth is but one country.";
	unsigned char strlength = 30;
	unsigned char i = 0;
	usart_init();
	while(1)
	{
		usart_send(str[i++]);
		if(i>=strlength)
		i=0;
	}
	return 0;
}
*/