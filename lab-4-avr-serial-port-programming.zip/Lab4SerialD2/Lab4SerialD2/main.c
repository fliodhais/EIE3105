/*
 * Lab4SerialC.c
 *
 * Created: 18-Nov-20 12:05:04 AM
 * Author : flow
 */ 

/*
//Interrupt method
//1.Send ��We Are Ready�� at first ,and when input
//��Hi�� send ��Bye!��

#include <avr/io.h>
#include <avr/interrupt.h>

unsigned char str[4]=("Bye!");
unsigned char strL=4;
unsigned int flag=0;
unsigned int i=0;
unsigned char start[13]=("We Are Ready!");
unsigned char startL=13;
unsigned int mode=0;
unsigned char read;

//initialize
void usart_init(void)
{	//enable transmitter and receiver and RXC and UDR
	UCSR0B=(1<<TXEN0) | (1<<UDRIE0)|(1<<RXEN0) | (1<<RXCIE0) ;
	UCSR0C=(1<<UCSZ01) | (1<<UCSZ00);
	UBRR0L=0XCF;											//baudrate=4800
	// UBRR0L=0X68;											//baudrate=9600
}

//Send
//Sending :When the serial port ready, send data
ISR(USART_UDRE_vect)
{
	if (mode==0)
	{
		//Can��t use for loop for sending sentence in interrupt!!!!!!
		UDR0=start[i];
		i++;
		if(i==13)
		{
			mode=1;
			i=0;
		}
	}
	if(flag==2)
	{
		//if receive is ��Hi��, sending Bye!
		UDR0=str[i];
		i++;
		if(i==4)
		{
			flag=0;
			i=0;
		}
	}
}

//Receive
//executed when anything receive (when a byte is copied and stored in UDR)
ISR(USART_RX_vect)
{
	read=UDR0;
	//Detect ��Hi��
	if (read==('H'))
	{
		flag=1;
	}
	else if(read==('i') && flag==1)
	{
		flag=2;
	}
}

int main(void)
{	
	usart_init();
	sei();													//enable interrupt
	while (1);
	return 0;
}
*/
//------------------------------------------------------------------------------
#include <avr/io.h>
#include <avr/interrupt.h>
unsigned char read;
unsigned char store;
unsigned int flag=0;
unsigned int i=0;

void usart_init(void)
{
		UCSR0B=(1<<TXEN0) | (1<<UDRIE0)|(1<<RXEN0) | (1<<RXCIE0) ;
		UCSR0C=(1<<UCSZ01) | (1<<UCSZ00);
		UBRR0L=0X68;//baudrate=9600
}

//Sending :When the serial port ready, send data
ISR(USART_UDRE_vect)
{
	if(flag==0)
	{
		UDR0='a';
	}
	
	else if(flag==1)
	{
		UDR0=read;
		store=read;
		i++;
		if(i==10)
		{
			flag=2;
			i=0;
		}
	}
}

//executed when anything receive (when a byte is copied and stored in UDR)
ISR(USART_RX_vect)
{
	read=UDR0;
	if(flag==0)
	{
		flag=1;
	}
	
	else if(flag==2)
	{
		if(read==store)
		{
			flag=0;
		}
	}
}

int main(void)
{
	usart_init();
	sei();
	while (1);
	return 0;
}

/*#include <avr/io.h>
#define fosc 16000000	//clock speed
#define baud 4800		//baud rate 9600 (originally 4800, changed due to teraterm's default value) (changed back to 4800 cause why not)
#define ubrr fosc/16/baud-1	//ubrr
unsigned char data;

void usart_init(void)
{
	UCSR0B = (1<<RXEN0)|(1<<TXEN0);			//enable receiver and transmitter
	UCSR0C = (1<<USBS0)|(3<<UCSZ00);		//set frame format: 2 stop bit, 8 data bit
	UBRR0L = ubrr;
}

//send data
void usart_send(unsigned char ch)
{
	while(!(UCSR0A&(1<<UDRE0)));	//wait for empty transmit buffer
	UDR0 = ch;						//put data into buffer, send data
}

//receive data
unsigned char usart_receive(void)
{
	while(!(UCSR0A & (1<<RXC0)));
	data = UDR0;
	return data;
}

int main(void)
{
	unsigned int flag;
	unsigned int i=0;
	unsigned char rec;
	usart_init();
	while (1)
	{
		//constantly send "a"
		while(!(UCSR0A&(1<<RXC0)))
		{
			while(!(UCSR0A&(1<<UDRE0)));
			UDR0='a';
		}
		rec=usart_receive();
		flag=rec;
		
		//send ten times "rec"
		for(i=0;i<10;i++)
		{
			usart_send(rec);
		}	
		
		rec=usart_receive();
		//receive n wait for receive=flag
		while(rec!=flag)
		{
			rec=usart_receive();
		}
	}
	return 0;
}
*/