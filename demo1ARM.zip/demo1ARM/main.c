#include "stm32f10x.h"                  // Device header
//#include "ADC_DMA.h"
#include "pinout.h"
#include "usart1-c8.h"
#include "led-indicator.h"
#include "tim3-pwm.h"
#include "stdio.h"
#include "misc.h"
#include "string.h"

#define UP    '1'
#define RIGHT	'2' 
#define DOWN	'3'
#define LEFT	'4'
#define TRIANGLE '4'
#define CIRCLE   '5'
#define CROSS    '6'
#define SQUARE   '7'

//function prototype declaration
void INDICATOR_LED_init(void);	
void TIM3_PWM_init(void);
void TIM2_init(void);
void USART2_init(void);
void USARTSend(char *pucBuffer, unsigned long ulCount);
void PWM_Update(int clk, int ch);

//private variables
unsigned char ledState=0;
unsigned char character, newCharacter, state;
unsigned char driveFlag = 0;

int main(void) {
	
	INDICATOR_LED_init();
	TIM2_init();
	TIM3_PWM_init();
	USART1_init();
	
	char buffer[50] = {'\0'};

	while(1) {
		
		if(ledFlag == 1)
			{				
			switch(ledState)	//flip-flop function that
				{
				
					case 0: 	//flashes LED
						GPIO_WriteBit(GPIOB, GPIO_Pin_12, Bit_SET);
						ledState =1;
						break;
					
					case 1: 	//and resets wheels @ 10hz
						GPIO_WriteBit(GPIOB, GPIO_Pin_12, Bit_RESET);
						ledState =0;
						TIM3->CCR1 = 1;
						TIM3->CCR2 = 1;
						TIM3->CCR3 = 1;
						TIM3->CCR4 = 1;
						break;
					
					default:
						break;
				}
			ledFlag = 0;
			}
		
		int HIGH = 500;						//1000 = 100%
		if(driveFlag == 1){
			driveFlag = 0;
			switch(character){
				
				case UP:
					TIM3->CCR1 = 1;
					TIM3->CCR2 = HIGH;	//right+
					TIM3->CCR3 = HIGH;	//left+
					TIM3->CCR4 = 1;
					break;
				
				case DOWN:
					TIM3->CCR1 = HIGH;	//right-
					TIM3->CCR2 = 1;
					TIM3->CCR3 = 1;
					TIM3->CCR4 = HIGH;	//left+
					break;
				
				case LEFT:
					TIM3->CCR1 = HIGH; //Right-
					TIM3->CCR2 = 1;
					TIM3->CCR3 = HIGH; //Left+
					TIM3->CCR4 = 1;
					break;
				
				case RIGHT:
					TIM3->CCR1 = 1;
					TIM3->CCR2 = HIGH; //Right+
					TIM3->CCR3 = 1;
					TIM3->CCR4 = HIGH; //Left-
					break;			

				default: 
					TIM3->CCR1 = 1;
					TIM3->CCR2 = 1;
					TIM3->CCR3 = 1;
					TIM3->CCR4 = 1;
				break;
				
			}		
		}
	}
}


void USARTSend(char *pucBuffer, unsigned long ulCount)
{
    // Loop while there are more characters to send.
    while(ulCount--)
    {
        USART_SendData(USART2, *pucBuffer++);// Last Version USART_SendData(USART1,(uint16_t) *pucBuffer++);
        //Loop until the end of transmission
        while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET)
        {
        }
    }
}

void USART1_IRQHandler() {
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {		//When receive
		character = (unsigned char) USART_ReceiveData(USART1);	//set character to rcv msg
		driveFlag = 1;																					//enter drive command loop
		state = 0;																							//
	}	
}

