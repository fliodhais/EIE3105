//Section B: Flash the on-board LED (PD2) by using a delay loop
/*
#include "stm32f10x.h"                  // Device header

void delay(int t);

int main(void) {
	
	//GPIO set up for PA5 (on-board LD2)
	//Enable APB2 periphral clock
	RCC->APB2ENR |= RCC_APB2Periph_GPIOA;

	GPIOA->CRL &= ~0x00F00000;  //clear the setting
	GPIOA->CRL |=  0 << 22 | 2 << 20; //GPIO_Mode_Out_PP, GPIO_Speed_2MHz
	
	while(1) {
		GPIOA->BSRR |= 0x20;
		delay(10000000);
		GPIOA->BRR  |= 0x20;
		delay(10000000);
	}
}

void delay(int t) {
	int i, j;
	for(i=0; i<t; i++)
		j++;
}
*/
//Section B end
//--------------------------------------------------------------------------------
//Section C: Flash the on-board LED (PA5) by using Systick.
/*
#include "stm32f10x.h"                  // Device header

void DelayMs(uint32_t ms);

static __IO uint32_t msTicks;

int main(void) {
	
	//GPIO set up for PA5 (on board LED)
	//Enable APB2 periphral clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	// Update SystemCoreClock value
	SystemCoreClockUpdate();
	
	// Configure the SysTick timer to overflow every 1 ms
	SysTick_Config(SystemCoreClock / 1000);
	
	while(1) {
		GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET);
		DelayMs(1000);
		GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
		DelayMs(1000);
	}	
}

void DelayMs(uint32_t ms)
{
	// Reload us value
	msTicks = ms;
	// Wait until usTick reach zero
	while (msTicks);
}

// SysTick_Handler function will be called every 1 ms
void SysTick_Handler()
{
	if (msTicks != 0)
	{
		msTicks--;
	}
}
*/
//Section C End
//----------------------------------------------------------------------------------------
//Section D: Use the on-board button (PC13) to switch on and off the on-board LED (PA5)
/*
#include "stm32f10x.h"                  // Device header
#include "stdbool.h"

//PC13
#define BUTTON_RCC_GPIO   RCC_APB2Periph_GPIOC
#define BUTTON_GPIO	      GPIOC
#define BUTTON_GPIO_PIN   GPIO_Pin_13
#define BUTTON_EXTI_LINE     EXTI_Line13
#define BUTTON_GPIO_PORTSOURCE GPIO_PortSourceGPIOC
#define BUTTON_GPIO_PINSOURCE  GPIO_PinSource13

#define L3_RCC_GPIO  RCC_APB2Periph_GPIOB
#define L3_GPIO      GPIOB
#define L3_R_PIN     GPIO_Pin_8
#define L3_G_PIN     GPIO_Pin_9

static bool state = false;
static bool state_changed = false;

int main(void) {
	//GPIO set up for PA5 (on board LED)
	//Enable APB2 periphral clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	// GPIO clock for I/O
	RCC_APB2PeriphClockCmd(BUTTON_RCC_GPIO, ENABLE);
   	RCC_APB2PeriphClockCmd(L3_RCC_GPIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	// Configure I/O for L3
	GPIO_InitStruct.GPIO_Pin = L3_R_PIN | L3_G_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(L3_GPIO, &GPIO_InitStruct);
 
	// Configure I/O for EXTI13
	GPIO_InitStruct.GPIO_Pin = BUTTON_GPIO_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(BUTTON_GPIO, &GPIO_InitStruct);
	
	// EXTI Configuration
	GPIO_EXTILineConfig(BUTTON_GPIO_PORTSOURCE, BUTTON_GPIO_PINSOURCE);
	EXTI_InitTypeDef EXTI_InitStruct;
	EXTI_InitStruct.EXTI_Line = BUTTON_EXTI_LINE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStruct);
	
	// Enable Interrupt
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    	NVIC_InitStruct.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x02;
	NVIC_Init(&NVIC_InitStruct);
	
	
	while(1) {
		if(state_changed) {
			if(state) {
				GPIO_SetBits(L3_GPIO, L3_R_PIN);
				GPIO_ResetBits(L3_GPIO, L3_G_PIN);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET);

			} else {
				GPIO_ResetBits(L3_GPIO, L3_R_PIN);
				GPIO_SetBits(L3_GPIO, L3_G_PIN);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);

			}
			state_changed = false;
		}
	}
}

void EXTI15_10_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line13) != RESET) {				
	state = !state;
	state_changed = true;
      	EXTI_ClearITPendingBit(EXTI_Line13);
    }
}
//*/
//Section D end
//---------------------------------------------------------
//Section E: Use the on-board button (PC13) to change the state of the on-board LED (PA5)
/*
#include "stm32f10x.h"                  // Device header
#include "stdbool.h"

//PC13
#define BUTTON_RCC_GPIO   RCC_APB2Periph_GPIOC
#define BUTTON_GPIO	      GPIOC
#define BUTTON_GPIO_PIN   GPIO_Pin_13
#define BUTTON_EXTI_LINE     EXTI_Line13
#define BUTTON_GPIO_PORTSOURCE GPIO_PortSourceGPIOC
#define BUTTON_GPIO_PINSOURCE  GPIO_PinSource13

#define L3_RCC_GPIO  RCC_APB2Periph_GPIOB
#define L3_GPIO      GPIOB
#define L3_R_PIN     GPIO_Pin_8
#define L3_G_PIN     GPIO_Pin_9

static bool state = false;
static bool state_changed = false;

int main(void) {
	//GPIO set up for PA5 (on board LED)
	//Enable APB2 periphral clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	// GPIO clock for I/O
	RCC_APB2PeriphClockCmd(BUTTON_RCC_GPIO, ENABLE);
   	RCC_APB2PeriphClockCmd(L3_RCC_GPIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	// Configure I/O for L3
	GPIO_InitStruct.GPIO_Pin = L3_R_PIN | L3_G_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(L3_GPIO, &GPIO_InitStruct);
 
	// Configure I/O for EXTI13
	GPIO_InitStruct.GPIO_Pin = BUTTON_GPIO_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(BUTTON_GPIO, &GPIO_InitStruct);
	
	// EXTI Configuration
	GPIO_EXTILineConfig(BUTTON_GPIO_PORTSOURCE, BUTTON_GPIO_PINSOURCE);
	EXTI_InitTypeDef EXTI_InitStruct;
	EXTI_InitStruct.EXTI_Line = BUTTON_EXTI_LINE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStruct);
	
	// Enable Interrupt
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    	NVIC_InitStruct.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x02;
	NVIC_Init(&NVIC_InitStruct);
	
	
	while(1) {
		if(state_changed) {
			if(state) {
				GPIO_SetBits(L3_GPIO, L3_R_PIN);
				GPIO_ResetBits(L3_GPIO, L3_G_PIN);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET);

			} else {
				GPIO_ResetBits(L3_GPIO, L3_R_PIN);
				GPIO_SetBits(L3_GPIO, L3_G_PIN);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);

			}
			state_changed = false;
		}
	}
}

void EXTI15_10_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line13) != RESET) {				
	state = !state;
	state_changed = true;
      	EXTI_ClearITPendingBit(EXTI_Line13);
    }
}
//*/
//Section E end
//---------------------------------------------------------------------------------------
//Section F:
/*
#include "stm32f10x.h"                  // Device header
#include "stdbool.h"


void delay(int t) {
	int i, j;
	for(i=0; i<t; i++)
		j++;
}

void reset(){
		GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_9, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_RESET);		
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_RESET);
}
int main(void) {
	//GPIO set up for PA5 (on board LED)
	//Enable APB2 periphral clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;		
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	

	*/
	//01 894 567 = gr gyr gyr
/*
5s 1 8 7 = 1000 0110 = 0x86
1s 1 9 7 = 1000 1010 = 0x8A
1s 1 4 7 = 1001 0010 = 0x92
1s 1 4 67 = 1101 0010 = 0xD2
5s 0 4 5 = 0011 0001 = 0x31
1s 0blink 4 6 = 0101 0001 = 0x51
1s 1 4 7 = 1001 0010 = 0x92
1s 1 94 7 = 1001 10l0 = 0x9A
	*/	
	/*
	while(1) {
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(50000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_9, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET);
				delay(50000000);
				reset();
				
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
					GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
					GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
					GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
					GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
				reset();
				
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_9, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
				
		
				


			} 
		}
	

*/

//Section F end
//------------------------------------
//Section G: Write a C program to count a switch
/*
#include "stm32f10x.h"                  // Device header
#include "stdbool.h"

//PC13
#define BUTTON_RCC_GPIO   RCC_APB2Periph_GPIOC
#define BUTTON_GPIO	      GPIOC
#define BUTTON_GPIO_PIN   GPIO_Pin_13
#define BUTTON_EXTI_LINE     EXTI_Line13
#define BUTTON_GPIO_PORTSOURCE GPIO_PortSourceGPIOC
#define BUTTON_GPIO_PINSOURCE  GPIO_PinSource13

#define L3_RCC_GPIO  RCC_APB2Periph_GPIOB
#define L3_GPIO      GPIOB
#define L3_R_PIN     GPIO_Pin_8
#define L3_G_PIN     GPIO_Pin_9

static bool state = false;
static bool state_changed = false;
int count=0;

int main(void) {
	//GPIO set up for PA5 (on board LED)
	//Enable APB2 periphral clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	// GPIO clock for I/O
	RCC_APB2PeriphClockCmd(BUTTON_RCC_GPIO, ENABLE);
   	RCC_APB2PeriphClockCmd(L3_RCC_GPIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	// Configure I/O for L3
	GPIO_InitStruct.GPIO_Pin = L3_R_PIN | L3_G_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(L3_GPIO, &GPIO_InitStruct);
 
	// Configure I/O for EXTI13
	GPIO_InitStruct.GPIO_Pin = BUTTON_GPIO_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(BUTTON_GPIO, &GPIO_InitStruct);
	
	// EXTI Configuration
	GPIO_EXTILineConfig(BUTTON_GPIO_PORTSOURCE, BUTTON_GPIO_PINSOURCE);
	EXTI_InitTypeDef EXTI_InitStruct;
	EXTI_InitStruct.EXTI_Line = BUTTON_EXTI_LINE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStruct);
	
	// Enable Interrupt
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    	NVIC_InitStruct.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x02;
	NVIC_Init(&NVIC_InitStruct);
	
	
	while(1) {
		if(state_changed) {
			if(state) {
				if(count==3){
				GPIO_SetBits(L3_GPIO, L3_R_PIN);
				GPIO_ResetBits(L3_GPIO, L3_G_PIN);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET);
				count=0;}
				

			} else {
				if(count==3){
				GPIO_ResetBits(L3_GPIO, L3_R_PIN);
				GPIO_SetBits(L3_GPIO, L3_G_PIN);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
				count=0;}
			}
			state_changed = false;
		}
	}
}

void EXTI15_10_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line13) != RESET) {				
	state = !state;
	state_changed = true;
			count++;
      	EXTI_ClearITPendingBit(EXTI_Line13);
    }
}
//*/
//Section G end
//----------------------------------------------------------------------------------
//Section H: Section H: Use an external hardware interrupt to enable the simulation of the traffic lights.
/*#include "stm32f10x.h"                  // Device header
#include "stdbool.h"

int poop=0;

void delay(int t) {
	int i, j;
	for(i=0; i<t; i++)
		j++;
}

void reset(){
		GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_9, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_RESET);		
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_RESET);
}
int main(void) {
	//GPIO set up for PA5 (on board LED)
	//Enable APB2 periphral clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;		
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	while(1) {
		if (poop==1){
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(50000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_9, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET);
				delay(50000000);
				reset();
				
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
					GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
					GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
					GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
					GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
				delay(500000);
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
				delay(1500000);
				reset();
				
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);
				GPIO_WriteBit(GPIOA, GPIO_Pin_9, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);
				delay(10000000);
				reset();
			}
		
				


			} 
		}
//*/
#include "stm32f10x.h"                  // Device header
#include "stdbool.h"

//PC13
#define BUTTON_RCC_GPIO   RCC_APB2Periph_GPIOC
#define BUTTON_GPIO	      GPIOC
#define BUTTON_GPIO_PIN   GPIO_Pin_13
#define BUTTON_EXTI_LINE     EXTI_Line13
#define BUTTON_GPIO_PORTSOURCE GPIO_PortSourceGPIOC
#define BUTTON_GPIO_PINSOURCE  GPIO_PinSource13

#define L3_RCC_GPIO  RCC_APB2Periph_GPIOB
#define L3_GPIO      GPIOB
#define L3_R_PIN     GPIO_Pin_8
#define L3_G_PIN     GPIO_Pin_9

static bool state = false;
static bool state_changed = false;

int main(void) {
	//GPIO set up for PA5 (on board LED)
	//Enable APB2 periphral clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	// GPIO clock for I/O
	RCC_APB2PeriphClockCmd(BUTTON_RCC_GPIO, ENABLE);
   	RCC_APB2PeriphClockCmd(L3_RCC_GPIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	// Configure I/O for L3
	GPIO_InitStruct.GPIO_Pin = L3_R_PIN | L3_G_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(L3_GPIO, &GPIO_InitStruct);
 
	// Configure I/O for EXTI13
	GPIO_InitStruct.GPIO_Pin = BUTTON_GPIO_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(BUTTON_GPIO, &GPIO_InitStruct);
	
	// EXTI Configuration
	GPIO_EXTILineConfig(BUTTON_GPIO_PORTSOURCE, BUTTON_GPIO_PINSOURCE);
	EXTI_InitTypeDef EXTI_InitStruct;
	EXTI_InitStruct.EXTI_Line = BUTTON_EXTI_LINE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStruct);
	
	// Enable Interrupt
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    	NVIC_InitStruct.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x02;
	NVIC_Init(&NVIC_InitStruct);
	
	
	while(1) {
		if(state_changed) {
			if(state) {
				GPIO_SetBits(L3_GPIO, L3_R_PIN);
				GPIO_ResetBits(L3_GPIO, L3_G_PIN);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET);

			} else {
				GPIO_ResetBits(L3_GPIO, L3_R_PIN);
				GPIO_SetBits(L3_GPIO, L3_G_PIN);
				GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);

			}
			state_changed = false;
		}
	}
}

void EXTI15_10_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line13) != RESET) {				
	state = !state;
	state_changed = true;
      	EXTI_ClearITPendingBit(EXTI_Line13);
    }
}
//Section H end
//--------------------------------------------------------------------------------------
//Section I: Write a C program to keep sending and receiving characters 
/*#include "stm32f10x.h"                  // Device header
#include "string.h"

char msg[] = "a";
//char bye[] = "Bye!";
static uint8_t msg_i=0;
char mem[] = "b";
static uint8_t mem_i=0;

int main(void) {

	msg_i=0;
	
	//USART2 TX RX
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure); 
	
	//USART2 ST-LINK USB
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
	
	USART_InitTypeDef USART_InitStructure;
	//USART_ClockInitTypeDef USART_ClockInitStructure; 
	
	USART_InitStructure.USART_BaudRate = 9600;
  	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
 	USART_InitStructure.USART_StopBits = USART_StopBits_1;
  	USART_InitStructure.USART_Parity = USART_Parity_No;
  	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	
	USART_Init(USART2, &USART_InitStructure);
	USART_Cmd(USART2, ENABLE);
	
	
	NVIC_InitTypeDef NVIC_InitStructure;
	// Enable the USART2 TX Interrupt 
	USART_ITConfig(USART2, USART_IT_TC, ENABLE );
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	// Enable the USART2 RX Interrupt
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE );
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	while(1) {}
}

unsigned char character, newCharacter, state=0;
int latch=0;
int x=0;

void USART2_IRQHandler() {
	if(USART_GetITStatus(USART2, USART_IT_TC) != RESET) {
		if(latch==0) {
			USART_SendData(USART2, msg[msg_i]);
		} 
		//USART_ClearITPendingBit(USART2, USART_IT_TC);
	}
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
		latch=1;
		character = (unsigned char) USART_ReceiveData(USART2); 
		USART_SendData(USART2, character);
	}	
}
*/
/*if(msg_i < strlen(msg)) {
			USART_SendData(USART2, msg[msg_i++]);
		}*/ 
//Section I end
