/*
 * Lab 2.c
 *
 * Created: 10/15/2020 10:02:07 AM
 * Author : Flow
 */ 

#include <avr/io.h>

/*
1. Write a C program to toggle a LED connected to PB0 (you should connect the LED to
PB0 with a resistor) in every second. You should use the timer with Normal mode to
generate the time delay of one second. Note that the clock frequency of the Arduino Start
Kit is 16 MHz.*/
void T1Delay();
int main(void)
{
    DDRB = 0xFF;	//port b output
    while (1) 
    {
		T1Delay();
		PORTB = PORTB ^ 1;	//toggle position 1 = PORTB.0
    }
}

//part 1 normal mode------------------------------------------
/*
void T1Delay()	//1 second function made from timer 1
{
	//declaring configurations
	TCNT1H = 0xc2;	//1s 16mhz 1024 prescaler, FFFF - 3d09 + 1(rollover) = c2f7
	TCNT1L = 0xf7;
	TCCR1A = 0x00;	//normal
	TCCR1B = 0x05;	//normal mode, 1024 prescaler
	
	//trigger conditions and reset 
	while ((TIFR1&(1<<TOV1))==0);	//wait for TOV1 to roll over
	TCCR1B = 0x00;	//turn off timer 1
	TIFR1 = 0x01<<TOV1;	//clear TOV1
}
*/

//part 2------------------------------------------------------
/*
void T1Delay()	//1 second function made from timer 1
{
	//declaring configurations
	OCR1H = 0x3d;	//1s 16mhz 1024 prescaler, 3d09
	OCR1L = 0x09;
	TCCR1A = 0x00;	//normal
	TCCR1B = 0x0D;	//CTC mode, 1024 prescaler
	
	//trigger conditions and reset
	while ((TIFR1&(1<<OCF1A))==0);	//wait for TOV1 to roll over
	TCCR1B = 0x00;	//turn off timer 1
	TIFR1 = 0x01<<OCF1A;	//clear TOV1
}
*/